# Internship Backend

A backend for internship projects: two ready-made APIs (REST + GraphQL) on top of a **real
PostgreSQL database** — [PGlite](https://pglite.dev/), Postgres compiled to WASM — with JWT auth,
relations, foreign keys and derived counts. Nothing to sign up for, no cloud service, no
configuration.

Two independent domains, pick the one your project needs:

- **social-network** — users, posts, comments, likes, groups
- **notes** — a Google-Keep-style notes/todos app with checklists

There are two ways to run it. Both serve the same endpoints from the same code:

| Mode                      | When to use it                                                                                   | Data lives in           |
| ------------------------- | ------------------------------------------------------------------------------------------------ | ----------------------- |
| **HTTP server** — default | Almost always. A real, callable API: curl, Postman, a second client, data shared between people. | a directory on disk     |
| **In-browser** — fallback | Only when the app must deploy as static files with nothing running, e.g. GitHub Pages.           | the browser's IndexedDB |

**Start with the server.** The in-browser mode exists for the static-hosting case and comes with
real limits: it lives inside one page, so nothing outside that page can call it — no curl, no
Postman — and every visitor gets their own private copy of the data. See
[Fallback: running in the browser](#fallback-running-in-the-browser).

**Contents**

[1. Install](#1-install) · [2. Run the backend](#2-run-the-backend) · [3. Log in](#3-log-in) ·
[4. Connect your frontend](#4-connect-your-frontend) · [Next.js](#connecting-a-nextjs-app) ·
[Postman](#postman-collections) · [Access tokens & refresh](#access-tokens--refresh) ·
[Accounts](#accounts) · [Pagination](#pagination) · [Request validation](#request-validation) ·
[What the database enforces](#what-the-database-enforces) ·
[Persistence & reset](#data-persistence--resetting) · [Deploying](#deploying-the-server) ·
[In-browser fallback](#fallback-running-in-the-browser) ·
[Endpoints: social](#api-endpoints-social-network) · [Endpoints: notes](#api-endpoints-notes)

## 1. Install

You were given a **tarball** — `sidekick-software-internship-backend-<version>.tgz`. That file is
the whole package: the HTTP server, the CLI, the in-browser library and the seed data. There is no
public npm package and no repository to clone; the tarball is the distribution.

Put it somewhere stable inside your project — npm records the path, so a temp folder or
`node_modules` will not do — and install from there:

```bash
npm install <path-to-tarball>
```

That writes a `file:` dependency into your `package.json`:

```jsonc
{
  "dependencies": {
    "@sidekick-software/internship-backend": "file:<path-to-tarball>",
  },
}
```

**Upgrading.** npm caches by path, so a new tarball at the same path is not always picked up. Keep
the version in the filename and install the new file, or clear the installed copy first:

```bash
rm -rf node_modules/@sidekick-software && npm install
```

Check what you actually have with `npm ls @sidekick-software/internship-backend`.

You now have four things:

|                                                                              |                                                                |
| ---------------------------------------------------------------------------- | -------------------------------------------------------------- |
| `npx internship-backend serve …`                                             | the HTTP API                                                   |
| `npx internship-backend vercel …`                                            | [deploying it with your frontend](#deploying-the-server)       |
| `npx internship-backend postman …`                                           | [Postman collections](#postman-collections) for every endpoint |
| `import { startMockingSocial } from "@sidekick-software/internship-backend"` | the [in-browser fallback](#fallback-running-in-the-browser)    |

## 2. Run the backend

```bash
# boots a real API on http://localhost:3000
npx internship-backend serve social
npx internship-backend serve notes --port 4000
```

| Option               | Env               | Default          | What it does                                                                                                                   |
| -------------------- | ----------------- | ---------------- | ------------------------------------------------------------------------------------------------------------------------------ |
| `-p, --port <n>`     | `PORT`            | `3000`           | Port to listen on                                                                                                              |
| `-d, --data-dir <p>` | `PGLITE_DATA_DIR` | `./.pglite-data` | Where the database files live                                                                                                  |
| `social` / `notes`   | `DOMAIN`          | `social`         | Which domain to serve                                                                                                          |
| —                    | `JWT_SECRET`      | `SIDEKICK`       | Signing key for access tokens — **set it** on anything reachable from the internet, or anyone can mint a token for any user id |

Add a script so you do not retype it, and put `.pglite-data/` in `.gitignore` — it is a database,
not source:

```jsonc
// package.json
{
  "scripts": {
    "backend": "internship-backend serve social --port 4000",
  },
}
```

On first run the schema is created and seeded from the bundled JSON fixtures; after that the
directory is your database. Existing databases are brought up to date by a small
[migration runner](#what-the-database-enforces) on every boot.

## 3. Log in

One account is seeded and ready to use in both domains:

`email: helena.hills@social.com`

`password: password789`

The other fixture users exist to be read about — they author posts, leave comments, show up in
"suggested" — but they have **no password and cannot sign in**. When you need more accounts that
can, create them yourself: see [Accounts](#accounts).

### What is in the database

| social-network |     | notes      |     |
| -------------- | --- | ---------- | --- |
| users          | 14  | users      | 10  |
| posts          | 66  | todos      | 60  |
| comments       | 130 | — active   | 30  |
| likes          | 392 | — archived | 15  |
| groups         | 10  | — trashed  | 15  |

Enough rows that a list needs [paging](#pagination) and a feed looks populated. Every post has at
least one like and one comment; 23 of the todos carry checklists.

## 4. Connect your frontend

Point the app at the server and send `Authorization: Bearer <token>` on protected endpoints.
Both `fetch` and `axios` work; nothing here is framework-specific. For Next.js there is a
[section of its own](#connecting-a-nextjs-app) — the App Router changes where the token can live.

In a Vite app the tidiest development setup is a proxy, which makes `/api/...` same-origin — then
there is no CORS and no base URL to thread through your code:

```ts
// vite.config.ts
export default defineConfig({
  server: { proxy: { '/api': 'http://localhost:3000' } },
});
```

Without a proxy, prefix requests with the server's URL (`VITE_API_URL=http://localhost:3000`).

### A full request, end to end

`POST /api/login` returns `{ token, refreshToken, expiresIn, refreshTokenExpiresAt, user }`. Send
`token` as `Authorization: Bearer <token>` on protected endpoints (marked ✅ in the tables below).
The refresh token, used to get a new pair once the access token expires, also comes back as an
`HttpOnly` cookie — ask for it with `credentials: 'include'` and the browser keeps it for you. See
[Access tokens & refresh](#access-tokens--refresh).

```ts
// 1. log in
const res = await fetch('/api/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  credentials: 'include', // stores the refresh cookie
  body: JSON.stringify({
    email: 'helena.hills@social.com',
    password: 'password789',
  }),
});
const { token, user } = await res.json();
localStorage.setItem('token', token);

// 2. read the current user
const me = await fetch('/api/me', {
  headers: { Authorization: `Bearer ${token}` },
}).then(r => r.json());

// 3. create a post
await fetch('/api/posts', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${token}`,
  },
  body: JSON.stringify({ title: 'Hello', content: 'World' }),
});
```

### GraphQL

Both domains expose GraphQL at `POST /api/graphql`:

```ts
const query = `
  query AllPosts {
    allPosts(limit: 10) { id title author { username } likesCount }
  }
`;

const { data } = await fetch('/api/graphql', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${localStorage.getItem('token')}`,
  },
  body: JSON.stringify({ query, operationName: 'AllPosts' }),
}).then(r => r.json());
```

The status codes follow the GraphQL-over-HTTP conventions. One runner serves both domains and both
transports, so they cannot answer differently:

| Status | When                                                                                                        |
| ------ | ----------------------------------------------------------------------------------------------------------- |
| `400`  | The document does not parse, or does not validate against the schema. Nothing executed.                     |
| `401`  | A resolver refused for want of a token (`UNAUTHENTICATED`), or credentials were wrong.                      |
| `200`  | Everything else — including a resolver that failed. Read `errors` in the body; `data` may be partly filled. |

There is one endpoint for every operation, so the path itself is never gated the way a protected
REST route is — each resolver checks the token instead. An anonymous call to an operation that
needs one still comes back as `401`, but with a GraphQL `errors` array explaining which field
refused, rather than an empty body from a guard that never reached your query.

> ⚠️ In the in-browser fallback these endpoints exist only inside your page — Postman and curl
> cannot reach them. Against the server they are ordinary HTTP.

## Connecting a Next.js app

Nothing about this backend is Next-specific — it is an HTTP API on another port. Three things
about Next itself are worth knowing before you wire it up.

### The port collides

`next dev` takes port 3000, which is also this backend's default. Move one of them:

```bash
npx internship-backend serve social --port 4000
```

Keeping both in `package.json` saves explaining it twice:

```jsonc
// package.json
{
  "scripts": {
    "backend": "internship-backend serve social --port 4000",
    "dev": "next dev",
    // one terminal for both: npm i -D concurrently
    "dev:all": "concurrently -n next,api \"npm:dev\" \"npm:backend\"",
  },
}
```

### Only `NEXT_PUBLIC_*` reaches the browser

```bash
# .env.local
NEXT_PUBLIC_API_URL=http://localhost:4000
```

A variable without that prefix is readable only on the server. Restart `next dev` after adding it —
the value is inlined at build time, not read at runtime.

```ts
// lib/config.ts
export const API_URL = process.env.NEXT_PUBLIC_API_URL!;
```

### Client and server components read the API differently

In a **client** component nothing changes from any other React app: `fetch` with the absolute URL,
the token from wherever you keep it, `Authorization: Bearer <token>`.

A **server** component runs in Node, so two habits break:

- **No relative URLs.** There is no page origin to resolve `/api/posts` against; always use
  `API_URL`.
- **No `localStorage`.** Whatever carries the token in the browser is unreachable here, so a
  server component cannot make an authenticated call on its own. Either render authenticated data
  from a client component, or give the server its own copy of the token — which is what a Route
  Handler in front of `/api/login` is for; see
  [Where to keep the tokens](#where-to-keep-the-tokens).

Public reads need no token at all, which makes them the natural thing to render on the server:

```tsx
// app/feed/page.tsx — a server component
import { API_URL } from '@/lib/config';

export default async function Feed() {
  const res = await fetch(`${API_URL}/api/posts?limit=10`, {
    // Next 14 caches server `fetch` by default and would serve a stale feed
    // forever. Next 15 does not, but saying so survives an upgrade either way.
    cache: 'no-store',
  });
  if (!res.ok) throw new Error(`Feed failed: ${res.status}`);

  const { items } = await res.json();
  return (
    <ul>
      {items.map((post: { id: number; title: string }) => (
        <li key={post.id}>{post.title}</li>
      ))}
    </ul>
  );
}
```

Use `cache: 'no-store'` on anything you mutate and re-read, or `next: { revalidate: 30 }` when a
slightly stale list is fine.

### Common Next.js problems

| Symptom                                       | Cause                                               | Fix                                                |
| --------------------------------------------- | --------------------------------------------------- | -------------------------------------------------- |
| `EADDRINUSE :3000`                            | Next and the backend both want 3000                 | `--port 4000` on the backend                       |
| `Failed to parse URL from /api/posts`         | a relative `fetch` in a server component            | use the absolute `API_URL`                         |
| `localStorage is not defined`                 | client-only code imported into server-rendered code | `'use client'`, and guard `typeof window`          |
| Data never updates                            | Next 14 cached the server `fetch`                   | `cache: 'no-store'`                                |
| `process.env.…` is `undefined` in the browser | missing the `NEXT_PUBLIC_` prefix                   | rename it, restart `next dev`                      |
| `401` on everything after a couple of hours   | the access token expired and nothing refreshed it   | [Access tokens & refresh](#access-tokens--refresh) |

### The in-browser fallback and Next.js

Don't, unless you must. MSW's service worker only exists in the browser, so a Next app using it
renders every server-side pass against no backend at all — and the whole point of Next is that
first pass. If you are deploying a Next app statically (`output: 'export'`) and truly cannot run a
server, start the worker from a client-only component and dynamically `import()` the library so it
never reaches the server bundle. Otherwise run the HTTP server and point `NEXT_PUBLIC_API_URL` at
it, hosted or local.

## Postman collections

Every endpoint of a domain, as a Postman collection you can import in one go — with a working
example body on each request, seeded ids that exist, and login already wired to the authentication
of everything else. Nothing is checked in and handed round: the collection is **generated**, so it
cannot describe endpoints the code no longer has.

There are two ways to get it. Both produce the same thing.

### a. Write the files with the CLI

Once the tarball is installed in your project:

```bash
npx internship-backend postman all --out-dir ./postman
```

```
./postman/internship-backend-social.postman_collection.json  (65 requests)
./postman/internship-backend-notes.postman_collection.json   (37 requests)
```

Then in Postman: **Import → Files** (or drag the `.json` onto the sidebar) → **Import**.

| Flag                   | Default                                           |                                                    |
| ---------------------- | ------------------------------------------------- | -------------------------------------------------- |
| `social`/`notes`/`all` | `all`                                             | which domain(s) to write                           |
| `-o, --out-dir <p>`    | the current folder                                | where to put the files                             |
| `-b, --base-url <u>`   | `http://localhost:3000` (social), `:4000` (notes) | what `{{baseUrl}}` starts as; one domain at a time |

```bash
# a collection aimed at a deployed instance
npx internship-backend postman social --base-url https://your-app.vercel.app
```

### b. Ask a running server for it

Any running instance serves its own collection:

```bash
curl -o social.postman_collection.json http://localhost:4000/api/postman
```

Better, skip the file: in Postman choose **Import → Link** and paste the URL —

```
http://localhost:4000/api/postman
```

— and Postman fetches it. This is the shortest path when you are using a **shared, already
deployed** instance and never installed the package: paste
`https://your-app.vercel.app/api/postman` and you are done. `{{baseUrl}}` comes back already
pointing at whichever host answered, forwarded proxy headers included, so an imported collection
works without editing anything. Re-import after an upgrade to pick up new endpoints — the
collection id is stable, so Postman replaces it instead of leaving you with three copies.

Add `?baseUrl=` to override that: `http://localhost:4000/api/postman?baseUrl=https://staging.example`.

### Using it

**Run `Auth › Login` first.** Its test script stores `token` and `refreshToken` as collection
variables, and every other request inherits them from the collection's bearer auth — so you never
copy a token by hand. When the access token expires two hours later, send `Auth › Refresh tokens`;
it overwrites both variables the same way.

Three variables are yours to change:

| Variable       | Default                           |                                                             |
| -------------- | --------------------------------- | ----------------------------------------------------------- |
| `baseUrl`      | wherever the collection came from | Point it at another instance to run the same requests there |
| `token`        | empty                             | Filled in by Login                                          |
| `refreshToken` | empty                             | Filled in by Login                                          |

What you get:

- **REST** — one request per endpoint, grouped in folders, each with an example body and path
  parameters already filled in with ids that exist in the seed data. Endpoints that work without a
  token are marked _No Auth_, so the collection also documents which those are.
- **GraphQL** — one request per operation in the schema, in Postman's GraphQL body mode, with
  every field of the return type selected and sample variables filled in. Trim what you do not need.
- **Descriptions** — what each endpoint does, whether it needs a token, and what it answers.

Anything that reads Postman v2.1 collections works too: Insomnia, Bruno, Hoppscotch and Yaak all
import these files directly.

### How it stays correct

A collection written by hand goes stale the first time somebody adds a route. This one comes from
two sources that cannot drift far from the running code:

- **REST** comes from `api-catalog/`, a plain-data description of every endpoint. A test compares
  it against the routes the Hono server actually registers **and** against the MSW handlers of the
  in-browser build, in both directions — so a route that is added, renamed or deleted without
  updating the catalog fails the build. A second test sends every example against a freshly seeded
  database and asserts the status it claims, which is what keeps the sample bodies and ids honest.
- **GraphQL** is read straight out of the SDL. Nothing is retyped, so a new query or a renamed
  argument turns up in the collection the moment it exists. The generated documents are validated
  against the schema and executed against a real server in the test suite.

The output is deterministic — same input, byte-identical file.

## Access tokens & refresh

Auth is a **two-token** scheme. Both are returned by `POST /api/login` and by `POST /api/refresh`:

| Field                   | What it is                                | Lifetime | Where it lives                             |
| ----------------------- | ----------------------------------------- | -------- | ------------------------------------------ |
| `token`                 | Access token — a signed JWT               | 2 h      | client only; nothing is stored server-side |
| `refreshToken`          | Opaque, single-use string                 | 30 days  | hashed row in the `sessions` table         |
| `expiresIn`             | Access-token lifetime in seconds (`7200`) | —        | —                                          |
| `refreshTokenExpiresAt` | ISO timestamp                             | —        | —                                          |

Only the access token goes in the `Authorization: Bearer` header. The refresh token is used once
the access token has expired, and in a browser you never have to touch it: login also returns it
as an `HttpOnly` cookie, which `POST /api/refresh` reads on its own. Sending it in the request
body works too — see [Where to keep the tokens](#where-to-keep-the-tokens).

### How refreshing works

Refresh is a **frontend** responsibility. The backend cannot reach into your app and hand it a new
token — it answers `TOKEN_EXPIRED` and waits. Nothing is renewed in the background: if your code
never calls `POST /api/refresh`, the session ends after two hours.

The shape of it: when a request comes back `401`, branch on the `code` in the body. `TOKEN_EXPIRED`
is the one worth acting on — exchange the refresh token for a new pair, keep the new access token,
and retry the request once. Every other `code` means the session is genuinely over, so clear what
you kept and show the login screen. A `503 AUTH_BACKEND_UNAVAILABLE` is neither: the database is
briefly unreachable, so hold on to the session and retry later rather than logging anyone out.

Two rules are what separate a working implementation from one that logs users out at random:

- **Use what comes back.** Each refresh consumes the token it was given, so replaying the old one
  guarantees the next attempt fails. With the refresh cookie the browser handles this for you; if
  you carry the token yourself, overwrite it every time.
- **Only ever have one refresh in flight.** Requests that expire together must share a single
  refresh and wait on its result — a shared promise, a mutex, whatever your stack offers. Without
  that, the losers replay a spent token, which the server reads as a leak and answers by killing
  the whole session.

Keep the logic in one place — a `fetch` wrapper, an axios interceptor, your query library's error
handler. Scattered across components is how the parallel-refresh bug gets in.

Refreshing on a timer before expiry is a fine alternative and avoids the stampede entirely;
`expiresIn` tells you how long you have. The cost is a timer that has to survive tab sleep and
clock changes, which is why reacting to the 401 is more common.

### Where to keep the tokens

The access token is built into a header by your own code, so your app has to be able to read it.
Keep it wherever you keep client state.

The refresh token is the one with a decision attached. It is valid for 30 days against the access
token's two hours and it survives the tab closing, so whatever can read it can hold the session
for a month. There are two supported places for it, and both are implemented:

| Refresh token in     | You receive it as                       | You send it back by                        |
| -------------------- | --------------------------------------- | ------------------------------------------ |
| **A cookie**         | `Set-Cookie` on login and every refresh | doing nothing; the browser attaches it     |
| **Your own storage** | `refreshToken` in the response body     | putting it in the `POST /api/refresh` body |

**In a browser, use the cookie.** Login sets `refreshToken` as an `HttpOnly`, `Secure`, `SameSite`
cookie, so no script on the page can read the value — including a script that should not be there.
Adding `credentials: 'include'` to login, refresh and logout is the whole client change;
`POST /api/refresh` reads the cookie whenever the body carries no token. The next section has the
code and the three things that have to line up.

**Outside a browser, use the body** — Postman, curl, a test runner, a native client. There is no
cookie jar there, which is why `refreshToken` is still in every response.

The two do not conflict: the body copy is sent even when the cookie is set, and a `refreshToken`
in the request body takes precedence over the cookie. Switching from one to the other changes your
app only.

### Using the cookie instead

`POST /api/login` sets the cookie alongside the JSON it already returns:

```
Set-Cookie: refreshToken=<token>; Path=/api; Expires=...; HttpOnly; SameSite=None; Secure
```

Ask for it with `credentials: 'include'` and the browser stores it where no script can read it.
From then on `POST /api/refresh` needs no body at all — the cookie is used whenever no
`refreshToken` is sent:

```js
const res = await fetch(`${API}/refresh`, {
  method: 'POST',
  credentials: 'include',
});

```

`POST /api/logout` clears the cookie, and so does a **failed** refresh — a spent one is dropped
rather than left for the browser to replay on every later call. The GraphQL mutation behaves the
same way: `refreshToken` is an optional argument, so `mutation { refresh { token } }` sent with
credentials is enough.

Two things have to line up, and the failure when they do not is silent:

- **`credentials: 'include'` on login, refresh _and_ logout.** Without it the browser neither
  stores the cookie nor sends it back, and `/api/refresh` answers `REFRESH_TOKEN_REQUIRED` with no
  hint as to why.
- **The server reflects your `Origin`** and sends `Access-Control-Allow-Credentials: true`, so any
  port works with nothing to configure. It no longer answers `Access-Control-Allow-Origin: *`: a
  browser refuses to send credentials to a wildcard origin, which is what used to make this
  impossible.

### Which 401 means what

Every 401 carries a `code`, and a client **must** branch on it — otherwise an interceptor will
loop trying to refresh for a visitor who was never logged in:

| `code`                   | Meaning                                      | What the client should do       |
| ------------------------ | -------------------------------------------- | ------------------------------- |
| `TOKEN_EXPIRED`          | The access token aged out                    | call `/api/refresh`, retry once |
| `UNAUTHENTICATED`        | Missing, malformed or logged-out token       | log in again                    |
| `REFRESH_TOKEN_INVALID`  | Unknown or already-revoked refresh token     | log in again                    |
| `REFRESH_TOKEN_EXPIRED`  | The refresh token itself aged out            | log in again                    |
| `REFRESH_TOKEN_REUSED`   | A consumed refresh token was replayed; every session from that login is revoked | log in again |
| `REFRESH_TOKEN_REQUIRED` | No `refreshToken` in the body or cookie (400, not 401) | fix the request                 |

`POST /api/refresh` has one more answer that is **not** a 401: if the database is unreachable it
replies `503 AUTH_BACKEND_UNAVAILABLE`. A tab left open through a server restart depends on the
distinction.

## Accounts

### Create one

```
POST /api/signup   { email, password, username?, firstName?, secondName? }
→ 201 { message, user }
```

The password is never stored — only a PBKDF2 hash of it, with a per-account salt. The new account
can log in immediately with `POST /api/login`.

Rejections: `400 VALIDATION_FAILED` (email not an address, password shorter than 8 characters,
field missing) and `409 EMAIL_TAKEN` (case-insensitive — `Ann@x.com` and `ann@x.com` are one
account, enforced by a unique index).

### Change email or password

```
PUT /api/account   { currentPassword, email?, password? }
Authorization: Bearer <token>
→ 200 { message, user, token?, refreshToken?, expiresIn? }
```

`currentPassword` is always required, so a stolen access token alone cannot take over the account.

Changing the **password** revokes every session of that user — anyone signed in on another device
is cut off — and the response carries a fresh `{ token, refreshToken, expiresIn }` so the caller
who made the change stays signed in. **Store them**, or you log yourself out. Changing only the
**email** leaves sessions alone and returns no tokens; the login simply moves to the new address.

Rejections: `401 INVALID_CREDENTIALS` (wrong `currentPassword`), `409 EMAIL_TAKEN`,
`400 VALIDATION_FAILED`, `404 USER_NOT_FOUND`.

Both are also available over GraphQL as the `signup` and `updateAccount` mutations, which report
the same codes as GraphQL errors.

## Pagination

`GET /api/posts`, `GET /api/me/posts` and `GET /api/todos` return a page, not a bare array:

```json
{
  "items": [],
  "total": 66,
  "limit": 20,
  "offset": 0
}
```

`total` is the number of rows that match, ignoring the page — without it a client has no way to
know whether to ask for more.

| Parameter | Default | Limits                              |
| --------- | ------- | ----------------------------------- |
| `limit`   | `20`    | non-negative integer, at most `100` |
| `offset`  | `0`     | non-negative integer                |

```bash
curl "http://localhost:3000/api/posts?limit=10&offset=20"
```

Anything that is not a non-negative integer, or a `limit` above 100, is `400 INVALID_PAGINATION`.
An `offset` past the end returns an empty `items` with the real `total`, not an error.

On the notes side the filter and the page combine: `GET /api/todos?status=ARCHIVED&limit=5`.

In GraphQL the arguments are optional — `allPosts(limit: 10, offset: 20)`,
`todos(status: ARCHIVED, limit: 5)` — and the queries still return plain lists. Ask `postsTotal`
or `todosTotal` for the count.

### Likes moved out of the post list

A post in a list carries `likesCount` and `commentsCount`, but **not** `likedByUsers`. That array
used to embed a full user row for every like into every post, so the response grew with
likes × posts rather than with posts: at fixture size `GET /api/posts` weighed about 148 KB. It is
now under 6 KB.

Fetch the likers when you actually need them:

```bash
curl http://localhost:3000/api/posts/101/likes    # → User[]
```

GraphQL keeps the `likedByUsers` field on `Post` — it is resolved per post, on demand, so you only
pay for it in queries that ask for it.

## Request validation

Every request body is parsed against a schema before a handler sees it — the same schema on both
transports, so a payload the in-browser mock refuses is refused by the server too, with the same
status. A bad payload is a `400`, never a `500`:

```bash
curl -X POST http://localhost:3000/api/posts \
  -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
  -d '{"title":"","content":"hi"}'
```

```json
{ "code": "VALIDATION_FAILED", "message": "title must be a non-empty string" }
```

The rules are small and worth knowing, because they are stricter than "any JSON will do":

- **An empty string counts as missing.** `title: ""` is rejected wherever a title is required.
  Fields that may legitimately be cleared — `description`, a todo's `content` — accept `""`.
- **Ids must be non-negative integers.** `{ "postId": "abc" }` is a `400`, not a database error.
- **On a `PUT` every field is optional, but a field that _is_ present must be valid.** `null`
  counts as absent: sending `{"title": null}` leaves the column alone rather than clearing it, and
  answers `200`. There is no "set this back to empty" for a required field; for the ones that may
  be cleared, send `""`.
- **Unknown fields are ignored**, so a typo in a field name fails silently — check the endpoint
  tables if a value does not stick.
- **A missing or unparseable body is treated as `{}`**, which then fails on the first required
  field with a message naming it.

Avatars are the one place where a name differs between transports: `PUT /api/profile` (and
`PUT /api/me` in notes) accepts **both** `photo` and `profileImage`, because REST has historically
used the first and GraphQL the second.

Path and query parameters are checked the same way: a non-integer `:postId` is
`400 VALIDATION_FAILED`, and a bad `limit`/`offset` is `400 INVALID_PAGINATION`
(see [Pagination](#pagination)).

## What the database enforces

This is a real Postgres, and the constraints are in the schema rather than in application code —
worth knowing, because they show up as behaviour your frontend has to handle:

- **Foreign keys, with `ON DELETE CASCADE`.** Deleting a post takes its comments and its likes with
  it; deleting a user takes their posts, comments, likes, todos and sessions. You will not find
  orphaned rows, and you do not have to clean up after a delete.
- **One like per (user, post).** A unique index, so a double-click cannot produce two likes.
  `POST /api/like` answers `already_liked` rather than failing, and the count does not move.
- **`todos.status` is a `CHECK` constraint** over `NOTES | ARCHIVED | TRASH`. Anything else is
  rejected before it reaches a row.
- **Emails are unique case-insensitively**, via a unique index on `lower(email)`.
- **Counts are derived, never stored.** `likesCount` and `commentsCount` are computed on read, so
  they cannot drift from the rows they count.

Constraints live in migrations rather than in `CREATE TABLE`, because the databases are not the
package's: one lives in a trainee's IndexedDB, another in a `.pglite-data` directory beside a running
server, and both are expected to survive an upgrade. Each migration runs once, inside a
transaction, and is recorded in a `_meta` table. A step that tightens a constraint deletes the rows
that would violate it first — so upgrading an old database can remove duplicate likes or orphaned
comments, and it logs a line to the console when it does.

## Data persistence & resetting

Where the data sits depends on how you run it:

- **Server** — the `--data-dir` directory (default `./.pglite-data`). It survives restarts and is
  shared by everyone calling that instance. Delete the directory to start from scratch.
- **In-browser fallback** — the browser's IndexedDB. It survives reloads, but it is private to
  each browser and shared with nobody.

To restore the original seed data — before checking an assignment, say — call the reset endpoint:

```bash
curl -X POST http://localhost:3000/api/__reset
```

This drops the `sessions` table too, so every refresh token issued before the reset stops working
and clients have to log in again. Accounts created with `POST /api/signup` are also gone; only the
seeded login remains.

The in-browser fallback answers `POST /api/__reset` as well, and exports the same thing as a
helper for code that would rather call a function:

```ts
import {
  resetSocialDb,
  resetNotesDb,
} from '@sidekick-software/internship-backend';
await resetSocialDb(); // or resetNotesDb()
```

## Deploying the server

Sooner or later your frontend has to live somewhere other than `localhost`, and it needs a backend
that does too. This package deploys **inside your own project**: one Vercel project serves your app
and its API from the same origin, so `/api/...` keeps working in production exactly as it does
behind the dev proxy. No second deployment, no base URL threaded through your code, no CORS, and
one free project per person rather than two.

It costs nothing on Vercel's Hobby plan, needs no credit card, and the instance never sleeps.

### Set it up

From the root of your own project, after installing the package:

```bash
npx internship-backend vercel social     # or: notes
```

That is the whole setup. It writes two files and prints what it did:

- **`api/index.mjs`** — the function. Vercel turns every file under `api/` into one, and this one
  hands the request to the backend, which routes it exactly as the local server does.
- **`vercel.json`** — the routing (`/api/...` → that function), `DOMAIN`, and the one line PGlite
  cannot live without: an `includeFiles` glob for its 16 MB of WASM, which it loads at runtime
  relative to its own module URL where Vercel's dependency tracer cannot see it.

Neither file can be shipped inside the package: Vercel builds functions from the `api/` directory
of the repository it deploys, and `includeFiles` is only accepted in `vercel.json` — not in a
function's own `config` export. So they are generated once and committed like any other file.

If your project already has a `vercel.json`, the command **merges** into it rather than replacing
it, and puts the API rewrite ahead of anything already there. That order matters: behind a
client-routing catch-all, every API call would be answered with your app's `index.html`. Run the
command again whenever you like — it changes nothing the second time, and it will not overwrite an
`api/index.mjs` you wrote yourself unless you pass `--force`.

Next.js routes through Next rather than a root `api/` directory, so there the command prints a
route handler to paste instead of guessing.

### Deploy

1. Commit both files and push to GitHub.
2. On vercel.com: **Add New → Project**, import the repository. Leave the framework preset, build
   command and output directory alone — they belong to your app, and Vercel detects them correctly.
3. Add **one** environment variable: `JWT_SECRET`, something long and random —
   `openssl rand -base64 32`. `DOMAIN` is already in `vercel.json`; a secret is not, which is why
   it is the one thing left for the dashboard. Without it the signing key is a constant that ships
   with this package and anyone can mint a token for any user id. Set it once and leave it —
   changing it invalidates every token already issued.
4. **Deploy.**

### Check it before you build anything against it

```bash
curl https://your-app.vercel.app/api/postman   # either domain — 200, the collection
curl https://your-app.vercel.app/api/posts     # social — 200, the feed
curl https://your-app.vercel.app/api/todos     # notes — 401, and that is the right answer
```

A `401` from the notes domain is the backend answering, not a failure: every notes endpoint needs a
token, so an unauthenticated `curl` proves the routing and the auth guard both work. Log in first
if you want data:

```bash
curl -X POST https://your-app.vercel.app/api/login \
  -H 'content-type: application/json' \
  -d '{"email":"helena.hills@social.com","password":"password789"}'
```

The first call runs the schema, the migrations and the seed: a couple of seconds on a laptop, a
little more on Vercel's single vCPU. Every call after that is single-digit milliseconds.

**Use the short production URL** — `your-app.vercel.app`. A deployment also gets a long generated
URL (`your-app-a1b2c3-you.vercel.app`), and new projects come with Deployment Protection on, which
covers exactly those long URLs and every preview deployment while leaving the production domain
public. A protected URL answers a login page, not JSON, so curl and Postman get HTML back. Either
stick to the short URL, or turn protection off under **Settings → Deployment Protection**.

In Postman use **Import → Link** with `https://your-app.vercel.app/api/postman`: `{{baseUrl}}`
comes back already pointing at your own deployment.

One project serves one domain, which is normally all you need. Both at once means two projects.

### Three things to expect

**1. Accounts created at runtime do not survive.** A Vercel function has a read-only filesystem
apart from `/tmp`, which belongs to one instance and is thrown away when that instance is
recycled. The next request boots a fresh database from the fixtures, which means:

- every account made with `POST /api/signup` is gone,
- every refresh token issued so far stops working,
- only the seeded login (`helena.hills@social.com`) remains.

Vercel does not document how long an idle instance lives, so there is no schedule to plan around.
Usually fine for coursework, where the data is meant to be reset anyway. It is _not_ fine for an
assignment like "register, then show me your profile next week". Nothing in this setup can make
runtime data durable; that needs a host with a real disk, which is a different deployment
altogether. `POST /api/__reset` restores the seed data on demand.

**2. The first request after a quiet spell is slow.** Two seconds or so for the boot, and a
production deployment that goes two weeks without traffic is archived, which adds about another
second to the request that wakes it. During a demo, hit any endpoint a minute before you present.

**3. Free usage pauses rather than bills.** Hobby includes 4 CPU-hrs of active CPU, 360 GB-hrs of
provisioned memory and a million invocations a month, per account. Run through it and the feature
is paused for 30 days instead of charged for — so do not point a polling loop at your own
instance. Two other Hobby details worth knowing: it is for personal, non-commercial use, and
runtime logs are kept for one hour.

### When it does not work

| Symptom                                                        | Cause                                                            | Fix                                                                 |
| -------------------------------------------------------------- | ---------------------------------------------------------------- | ------------------------------------------------------------------- |
| Every `/api/...` path answers your app's HTML, or a plain `404` | the rewrite is gone, or was moved below a client-routing catch-all | re-run `npx internship-backend vercel`; it restores the order       |
| `500`, and the runtime log mentions `pglite.wasm` or `ENOENT`   | the `includeFiles` glob was dropped from `vercel.json`            | re-run the command                                                  |
| HTML with a Vercel login screen instead of JSON                | Deployment Protection, which covers generated and preview URLs    | the short production URL, or **Settings → Deployment Protection**   |
| `401` on everything, including the seeded login                | `JWT_SECRET` changed between deployments                          | set it once and leave it                                            |

Runtime logs live for an hour on Hobby, so look at them right after a failure.

### Handing the package out

The distribution is a tarball. Build it from a clone:

```bash
npm install
npm pack            # runs the build first; writes sidekick-software-internship-backend-<version>.tgz
```

`npm pack` runs the `prepare` script, so the tarball always contains a fresh `dist/` even though
`dist/` is git-ignored. Bump `version` in `package.json` before packing — trainees install by
filename, and a new version number is what tells them (and npm) that anything changed.

If you also want to hand out the Postman files rather than let people generate them:

```bash
npm run postman     # writes ./postman/*.postman_collection.json
```

But prefer pointing people at `GET /api/postman` on the instance they actually call: a file emailed
round is stale the next time an endpoint changes.

### Calling a server that lives somewhere else

In the deployment above your app and its API share an origin, so relative `/api/...` calls work in
production exactly as they do behind the dev proxy, and there is no base URL to configure at all.

You only need an absolute URL when you point a frontend at a server running somewhere else — a
`serve` instance on a colleague's machine, or your own from a phone on the same network. Set the
API base in the frontend build (`VITE_API_URL=https://…` for Vite, `NEXT_PUBLIC_API_URL=https://…`
for Next.js) and prefix requests with it. Nothing to configure server-side: the server sends open
CORS headers and the JWT travels in the `Authorization` header, so cross-origin calls just work.

Either way you no longer call `startMockingSocial` / `startMockingNotes` — those start the
in-browser database and its request interceptor, and a real server needs neither.

## Fallback: running in the browser

Use this only when the app has to be a pile of static files with no server behind it — GitHub
Pages being the usual reason. Calls to `/api/...` are intercepted by [MSW](https://mswjs.io/) and
answered from a PGlite database in the browser's IndexedDB.

Know the trade-offs before choosing it:

- The API exists **only inside your page**. Postman, curl and any other client cannot reach it —
  including `GET /api/postman`, which is a server-only endpoint.
- Every visitor gets a **separate** database in their own browser. Nothing is shared.
- Auth works exactly the same, but nothing in a page can keep a token out of JavaScript's reach,
  so treat the session as visible to any script running there.

### Step 1 — configure your bundler (Vite)

PGlite ships a WASM binary and a web worker, so the bundler needs two settings.
**Without this, PGlite will fail to load.**

```ts
// vite.config.ts
import { defineConfig } from 'vite';

export default defineConfig({
  base: '/<your-repo-name>/', // GitHub Pages project site; omit for a root/user site
  optimizeDeps: { exclude: ['@electric-sql/pglite'] },
  worker: { format: 'es' },
});
```

### Step 2 — generate the MSW service worker

MSW serves requests through a service-worker script that must live at your app's root. Run once
(commit the generated file):

```bash
npx msw init public
```

This creates `public/mockServiceWorker.js`.

### Step 3 — start the backend before your app renders

Call `startMockingSocial` (or `startMockingNotes`) and **await it** before rendering. Pass your
GitHub Pages **repository name** so the service worker is found under the project sub-path;
pass nothing for local dev.

```tsx
// main.tsx
import React from 'react';
import ReactDOM from 'react-dom/client';
import { startMockingSocial } from '@sidekick-software/internship-backend';
import App from './App';

async function bootstrap() {
  // '' (or omit) for localhost; '<your-repo-name>' when deployed to GitHub Pages
  await startMockingSocial(import.meta.env.PROD ? '<your-repo-name>' : '');

  ReactDOM.createRoot(document.getElementById('root')!).render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  );
}

bootstrap();
```

On first run the schema is created and seeded; from then on every `fetch('/api/...')` your app
makes is answered from the in-browser Postgres. Nothing is served from static JSON — MSW only
routes the request, and every response is a real SQL query. The `startMocking*` names are kept for
backwards compatibility.

### Step 4 — deploying to GitHub Pages

- Set Vite `base: '/<repo-name>/'` so the WASM/worker assets resolve under the project path.
- Run `npx msw init public` and pass the same `<repo-name>` to `startMockingSocial` /
  `startMockingNotes`.
- Use a **hash router** (or a `404.html` SPA fallback) for client-side routing.
- No `SharedArrayBuffer` / COOP-COEP headers are required — plain static hosting is enough.

## API endpoints (social network)

✅ = the request is refused without `Authorization: Bearer <token>`.
❌ = callable anonymously. `POST /api/logout` is ❌ so that it still works with an expired token,
but send the token anyway — it is the one logout invalidates.

That column is not a description of what the handlers happen to do: one list decides it for both
transports, and a route that is not on it is refused before any handler runs. Adding an endpoint
therefore makes it protected by default. A test compares this table's source against that list, so
the ticks cannot quietly go out of date.

##### REST API

| Method | Path                          | Auth | Description                                                    | Body                                                    | Response                                                |
| ------ | ----------------------------- | :--: | -------------------------------------------------------------- | ------------------------------------------------------- | ------------------------------------------------------- |
|        | 🟦 Posts                      |      |                                                                |                                                         |                                                         |
| GET    | `/api/posts`                  |  ❌  | Get posts, [paged](#pagination)                                | -                                                       | [Page](#pagination) of [Post](#post) (+ `authorPhoto`)  |
| GET    | `/api/posts/:postId/likes`    |  ❌  | Who liked this post                                            | -                                                       | [User](#user)[]                                         |
| POST   | `/api/posts`                  |  ✅  | Create post (201)                                              | { title, content, image? }                              | [Post](#post)                                           |
| PUT    | `/api/posts/:postId`          |  ✅  | Update post — author only                                      | { title?, content?, image? }                            | [Post](#post)                                           |
| DELETE | `/api/posts/:postId`          |  ✅  | Delete post — author only, cascades                            | -                                                       | (204) No content                                        |
|        | 🟦 Comments                   |      |                                                                |                                                         |                                                         |
| GET    | `/api/comments`               |  ❌  | Every comment, unpaged                                         | -                                                       | [Comment](#comment)[]                                   |
| GET    | `/api/posts/:postId/comments` |  ✅  | Comments on a post                                             | -                                                       | [Comment](#comment)[]                                   |
| POST   | `/api/comments`               |  ✅  | New comment (201)                                              | { postId, text }                                        | [Comment](#comment)                                     |
| PUT    | `/api/comments/:commentId`    |  ✅  | Update comment — author only                                   | { text }                                                | [Comment](#comment)                                     |
| DELETE | `/api/comments/:commentId`    |  ✅  | Delete comment — author only                                   | -                                                       | (204) No content                                        |
|        | 🟦 Likes                      |      |                                                                |                                                         |                                                         |
| POST   | `/api/like`                   |  ✅  | Like a post — idempotent                                       | { postId }                                              | [LikeStatus](#likestatus)                               |
| POST   | `/api/dislike`                |  ✅  | Remove your like                                               | { postId }                                              | [LikeStatus](#likestatus)                               |
|        | 🟦 Groups                     |      |                                                                |                                                         |                                                         |
| GET    | `/api/groups`                 |  ✅  | Get all groups                                                 | -                                                       | [Group](#group)[]                                       |
| GET    | `/api/groups/:groupId`        |  ✅  | Get group by id                                                | -                                                       | [Group](#group)                                         |
| POST   | `/api/groups`                 |  ✅  | Create group (201)                                             | { title, photo? }                                       | [Group](#group)                                         |
| PUT    | `/api/groups/:groupId`        |  ✅  | Update group                                                   | { title?, photo? }                                      | [Group](#group)                                         |
| DELETE | `/api/groups/:groupId`        |  ✅  | Delete group                                                   | -                                                       | (204) No content                                        |
|        | 🟦 Users                      |      |                                                                |                                                         |                                                         |
| PUT    | `/api/profile`                |  ✅  | Update your profile                                            | {_profile fields_}                                      | [User](#user)                                           |
| GET    | `/api/getSuggested`           |  ✅  | Everyone except you                                            | -                                                       | [SuggestedUser](#suggesteduser)[]                       |
| GET    | `/api/users/:userId`          |  ❌  | Get user by id                                                 | -                                                       | [User](#user)                                           |
|        | 🟦 Me                         |      |                                                                |                                                         |                                                         |
| GET    | `/api/me`                     |  ✅  | Your profile                                                   | -                                                       | [User](#user)                                           |
| GET    | `/api/me/posts`               |  ✅  | Your posts, [paged](#pagination)                               | -                                                       | [Page](#pagination) of [Post](#post)                    |
| GET    | `/api/me/comments`            |  ✅  | Your comments                                                  | -                                                       | [Comment](#comment)[]                                   |
| GET    | `/api/me/comments/count`      |  ✅  | How many you wrote                                             | -                                                       | { count: Int }                                          |
| GET    | `/api/me/likes`               |  ✅  | Your likes                                                     | -                                                       | [Like](#like)[]                                         |
| GET    | `/api/me/likes/count`         |  ✅  | How many you gave                                              | -                                                       | { count: Int }                                          |
|        | 🟦 Auth                       |      |                                                                |                                                         |                                                         |
| POST   | `/api/login`                  |  ❌  | Log in                                                         | { email, password }                                     | [Tokens](#access-tokens--refresh) + user: [User](#user) |
| POST   | `/api/refresh`                |  ❌  | Exchange a refresh token                                       | { refreshToken }                                        | [Tokens](#access-tokens--refresh)                       |
| POST   | `/api/signup`                 |  ❌  | Register (201)                                                 | { email, password, username?, firstName?, secondName? } | { message, user }                                       |
| POST   | `/api/logout`                 |  ❌  | Revoke the session                                             | { refreshToken? }                                       | { message }                                             |
| PUT    | `/api/account`                |  ✅  | Change email or password                                       | { currentPassword, email?, password? }                  | { message, user, token?, refreshToken?, expiresIn? }    |
|        | 🟦 Utility                    |      |                                                                |                                                         |                                                         |
| POST   | `/api/upload-image`           |  ❌  | Upload stub — stores nothing (201)                             | FormData                                                | { url: string }                                         |
| POST   | `/api/__reset`                |  ❌  | Drop everything and reseed                                     | -                                                       | { message }                                             |
| GET    | `/api/postman`                |  ❌  | [This domain's collection](#postman-collections) — server only | -                                                       | Postman v2.1 collection                                 |
| POST   | `/api/graphql`                |  ❌  | [Every operation](#graphql)                                    | { query, variables?, operationName? }                   | { data?, errors? }                                      |

##### GraphQL

Arguments are the schema's own — note that most "by id" operations take `id`, not `postId`.

| Type     | Operation         | Auth | Arguments                              | Response                                                |
| -------- | :---------------- | :--: | -------------------------------------- | ------------------------------------------------------- |
|          | 🟦 Auth           |      |                                        |                                                         |
| Mutation | `login`           |  ❌  | `email: String!`, `password: String!`  | LoginResponse: { token, refreshToken, expiresIn, user } |
| Mutation | `refresh`         |  ❌  | `refreshToken: String!`                | RefreshResponse: { token, refreshToken, expiresIn }     |
| Mutation | `signup`          |  ❌  | `email: String!`, `password: String!`  | SignupResponse: { message, user }                       |
| Mutation | `updateAccount`   |  ✅  | `input: UpdateAccountInput!`           | { message, user, token, refreshToken, expiresIn }       |
| Mutation | `logout`          |  ❌  | `refreshToken: String`                 | `Boolean!`                                              |
|          | 🟦 User           |      |                                        |                                                         |
| Query    | `me`              |  ✅  | -                                      | [User](#user)                                           |
| Query    | `suggestedUsers`  |  ✅  | -                                      | [SuggestedUser](#suggesteduser)[]                       |
| Query    | `mePosts`         |  ✅  | `limit: Int`, `offset: Int`            | [Post](#post)[]                                         |
| Query    | `meComments`      |  ✅  | -                                      | [Comment](#comment)[]                                   |
| Query    | `meCommentsCount` |  ✅  | -                                      | `Int!`                                                  |
| Query    | `meLikes`         |  ✅  | -                                      | [Like](#like)[]                                         |
| Query    | `meLikesCount`    |  ✅  | -                                      | `Int!`                                                  |
| Mutation | `updateProfile`   |  ✅  | `input: UpdateProfileInput!`           | [User](#user)                                           |
|          | 🟦 Posts          |      |                                        |                                                         |
| Query    | `allPosts`        |  ❌  | `limit: Int`, `offset: Int`            | [Post](#post)[]                                         |
| Query    | `postsTotal`      |  ❌  | -                                      | `Int!`                                                  |
| Query    | `post`            |  ✅  | `id: Int!`                             | [Post](#post)                                           |
| Mutation | `createPost`      |  ✅  | `input: CreatePostInput!`              | [Post](#post)                                           |
| Mutation | `updatePost`      |  ✅  | `id: Int!`, `input: CreatePostInput!`  | [Post](#post)                                           |
| Mutation | `deletePost`      |  ✅  | `id: Int!`                             | `Boolean!`                                              |
| Mutation | `likePost`        |  ✅  | `postId: Int!`                         | [Post](#post)                                           |
| Mutation | `dislikePost`     |  ✅  | `postId: Int!`                         | [Post](#post)                                           |
|          | 🟦 Comments       |      |                                        |                                                         |
| Query    | `postComments`    |  ✅  | `postId: Int!`                         | [Comment](#comment)[]                                   |
| Query    | `allComments`     |  ✅  | -                                      | [Comment](#comment)[]                                   |
| Mutation | `createComment`   |  ✅  | `postId: Int!`, `text: String!`        | [Comment](#comment)                                     |
| Mutation | `updateComment`   |  ✅  | `id: Int!`, `text: String!`            | [Comment](#comment)                                     |
| Mutation | `deleteComment`   |  ✅  | `id: Int!`                             | `Boolean!`                                              |
|          | 🟦 Groups         |      |                                        |                                                         |
| Query    | `allGroups`       |  ✅  | -                                      | [Group](#group)[]                                       |
| Query    | `group`           |  ✅  | `id: Int!`                             | [Group](#group)                                         |
| Mutation | `createGroup`     |  ✅  | `input: CreateGroupInput!`             | [Group](#group)                                         |
| Mutation | `updateGroup`     |  ✅  | `id: Int!`, `input: CreateGroupInput!` | [Group](#group)                                         |
| Mutation | `deleteGroup`     |  ✅  | `id: Int!`                             | `Boolean!`                                              |

`Post.author` and `Post.likedByUsers` are resolved on demand, so ask for them only in the queries
that need them. Input shapes: `CreatePostInput { title!, content!, image }`,
`CreateGroupInput { title!, photo }`, `UpdateProfileInput { username, email, firstName, secondName,
description, profileImage }`, `UpdateAccountInput { currentPassword!, email, password }`.

##### TYPES

##### User

[(return to table)](#rest-api)

| Field        | Type    |
| ------------ | ------- |
| id           | Int     |
| username     | String  |
| email        | String? |
| firstName    | String? |
| profileImage | String? |
| description  | String? |
| bio          | String? |
| secondName   | String? |
| lastLogin    | String? |
| creationDate | String? |
| modifiedDate | String? |

The password hash is never part of this shape. Every endpoint that returns a user names its
columns explicitly so the hash cannot leak, and a test asserts it is absent from all of them.
(`bio` exists in the REST shape only; the GraphQL `User` type does not expose it.)

##### SuggestedUser

[(return to table)](#rest-api)

`GET /api/getSuggested` returns a trimmed shape, and its avatar field is called `photo`, not
`profileImage`:

| Field       | Type    |
| ----------- | ------- |
| id          | Int     |
| username    | String  |
| firstName   | String? |
| secondName  | String? |
| description | String? |
| photo       | String? |

##### Post

[(return to table)](#rest-api)

| Field         | Type    |
| ------------- | ------- |
| id            | Int     |
| title         | String  |
| content       | String  |
| image         | String? |
| authorId      | Int     |
| likesCount    | Int     |
| commentsCount | Int     |
| creationDate  | String  |
| modifiedDate  | String  |

`likesCount` and `commentsCount` are derived on read, so they cannot drift from the rows they
count. The list of users who liked a post is **not** part of this shape — fetch it from
`GET /api/posts/:postId/likes`, or ask for `likedByUsers` in GraphQL, where it is resolved on
demand.

`GET /api/posts` adds one field, `authorPhoto`: that post's own author's avatar (or
`/assets/default-user.png` when they have none), fetched for the whole page in a single query so a
feed does not cost one request per row. The other post endpoints do not include it.

##### Comment

[(return to table)](#rest-api)

| Field        | Type   |
| ------------ | ------ |
| id           | Int    |
| text         | String |
| authorId     | Int    |
| postId       | Int    |
| creationDate | String |
| modifiedDate | String |

##### Like

[(return to table)](#rest-api)

| Field        | Type   |
| ------------ | ------ |
| id           | Int    |
| postId       | Int    |
| userId       | Int    |
| creationDate | String |

##### LikeStatus

[(return to table)](#rest-api)

What `POST /api/like` and `POST /api/dislike` answer. Liking is idempotent per (user, post) — a
unique index makes sure of it — so a second like is reported rather than rejected:

| Field         | Type   |                                                                                  |
| ------------- | ------ | -------------------------------------------------------------------------------- |
| status        | String | `liked` / `already_liked` from `/like`, `disliked` / `not_liked` from `/dislike` |
| postId        | Int    |                                                                                  |
| newLikesCount | Int    | the count after the call — render this, do not increment locally                 |

A post that does not exist is `404 { message }`.

##### Group

[(return to table)](#rest-api)

| Field        | Type    |
| ------------ | ------- |
| id           | Int     |
| title        | String  |
| photo        | String? |
| membersCount | Int     |

## API endpoints (notes)

Notes are private: every todo belongs to one user, and nothing but the auth surface is readable
anonymously.

##### REST API

| Method | Path                                     | Auth | Description                                                                                | Body                                                            | Response                                                      |
| :----: | ---------------------------------------- | :--: | ------------------------------------------------------------------------------------------ | --------------------------------------------------------------- | ------------------------------------------------------------- |
|        | 🟦 Todos                                 |      |                                                                                            |                                                                 |                                                               |
|  GET   | `/api/todos?status=`                     |  ✅  | Your todos by status (`NOTES`, `ARCHIVED`, `TRASH`; default `NOTES`), [paged](#pagination) | -                                                               | [Page](#pagination) of [Todo](#todo)                          |
|  POST  | `/api/todos`                             |  ✅  | Create a todo (201)                                                                        | { title, content?, items?: [{ text }] }                         | [Todo](#todo)                                                 |
|  PUT   | `/api/todos/:todoId`                     |  ✅  | Update a todo — sending `items` **replaces** the whole checklist                           | { title?, content?, items?: [CheckListItem](#checklistitem)[] } | [Todo](#todo)                                                 |
|  POST  | `/api/todos/:todoId/status`              |  ✅  | Move between statuses                                                                      | { newStatus: `NOTES` \| `ARCHIVED` \| `TRASH` }                 | [Todo](#todo)                                                 |
| DELETE | `/api/todos/:todoId`                     |  ✅  | Delete a todo, whatever its status                                                         | -                                                               | (204) No content                                              |
| DELETE | `/api/todos/deleteAll`                   |  ✅  | Empty the trash — 404 if it is already empty                                               | -                                                               | (204) No content                                              |
|  PUT   | `/api/todos/unarchiveAll`                |  ✅  | Move all `ARCHIVED` back to `NOTES` — 404 if there were none                               | -                                                               | [Todo](#todo)[]                                               |
|        | 🟦 Checklist                             |      |                                                                                            |                                                                 |                                                               |
|  PUT   | `/api/todos/:todoId/item/:itemId/toggle` |  ✅  | Toggle one item — `itemId` is scoped to the todo                                           | -                                                               | [Todo](#todo)                                                 |
|  PUT   | `/api/todos/:todoId/uncheckAll`          |  ✅  | Uncheck every item — 400 if the todo has no checklist                                      | -                                                               | [Todo](#todo)                                                 |
|  PUT   | `/api/background`                        |  ✅  | Set one background on **all** your todos                                                   | { backgroundImage: string }                                     | [Todo](#todo)[]                                               |
|        | 🟦 User                                  |      |                                                                                            |                                                                 |                                                               |
|  GET   | `/api/me`                                |  ✅  | Your profile                                                                               | -                                                               | [User](#user_notes)                                           |
|  PUT   | `/api/me`                                |  ✅  | Update your profile                                                                        | { username?, email?, description?, profileImage?, … }           | [User](#user_notes)                                           |
|        | 🟦 Auth                                  |      |                                                                                            |                                                                 |                                                               |
|  POST  | `/api/login`                             |  ❌  | Log in                                                                                     | { email, password }                                             | [Tokens](#access-tokens--refresh) + user: [User](#user_notes) |
|  POST  | `/api/refresh`                           |  ❌  | Exchange a refresh token                                                                   | { refreshToken }                                                | [Tokens](#access-tokens--refresh)                             |
|  POST  | `/api/signup`                            |  ❌  | Register (201) — the new account starts with no todos                                      | { email, password, username? }                                  | { message, user }                                             |
|  POST  | `/api/logout`                            |  ❌  | Revoke the session                                                                         | { refreshToken? }                                               | { message }                                                   |
|  PUT   | `/api/account`                           |  ✅  | Change email or password                                                                   | { currentPassword, email?, password? }                          | { message, user, token?, refreshToken?, expiresIn? }          |
|        | 🟦 Utility                               |      |                                                                                            |                                                                 |                                                               |
|  POST  | `/api/upload-image`                      |  ❌  | Upload stub — stores nothing (201)                                                         | FormData                                                        | { url: string }                                               |
|  POST  | `/api/__reset`                           |  ❌  | Drop everything and reseed                                                                 | -                                                               | { message }                                                   |
|  GET   | `/api/postman`                           |  ❌  | [This domain's collection](#postman-collections) — server only                             | -                                                               | Postman v2.1 collection                                       |
|  POST  | `/api/graphql`                           |  ❌  | [Every operation](#graphql)                                                                | { query, variables?, operationName? }                           | { data?, errors? }                                            |

##### GraphQL

| Type     | Operation                 | Auth | Arguments                                         | Response                                          |
| -------- | :------------------------ | :--: | ------------------------------------------------- | ------------------------------------------------- |
|          | 🟦 Auth                   |      |                                                   |                                                   |
| Mutation | `login`                   |  ❌  | `email: String!`, `password: String!`             | LoginResponse                                     |
| Mutation | `refresh`                 |  ❌  | `refreshToken: String!`                           | RefreshResponse                                   |
| Mutation | `signup`                  |  ❌  | `email: String!`, `password: String!`             | SignupResponse: { message, user }                 |
| Mutation | `updateAccount`           |  ✅  | `input: UpdateAccountInput!`                      | { message, user, token, refreshToken, expiresIn } |
| Mutation | `logout`                  |  ❌  | `refreshToken: String`                            | { message }                                       |
|          | 🟦 User                   |      |                                                   |                                                   |
| Query    | `me`                      |  ✅  | -                                                 | [User](#user_notes)                               |
| Mutation | `updateProfile`           |  ✅  | `input: UpdateProfileInput!`                      | [User](#user_notes)                               |
|          | 🟦 Todos                  |      |                                                   |                                                   |
| Query    | `todos`                   |  ✅  | `status: NoteStatus`, `limit: Int`, `offset: Int` | [Todo](#todo)[]                                   |
| Query    | `todosTotal`              |  ✅  | `status: NoteStatus`                              | `Int!`                                            |
| Mutation | `createTodo`              |  ✅  | `input: CreateTodoInput!`                         | [Todo](#todo)                                     |
| Mutation | `updateTodo`              |  ✅  | `id: Int!`, `input: UpdateTodoInput!`             | [Todo](#todo)                                     |
| Mutation | `changeTodoStatus`        |  ✅  | `id: Int!`, `newStatus: NoteStatus!`              | [Todo](#todo)                                     |
| Mutation | `deleteTodo`              |  ✅  | `id: Int!`                                        | { id, success }                                   |
|          | 🟦 Checklist              |      |                                                   |                                                   |
| Mutation | `toggleChecklistItem`     |  ✅  | `todoId: Int!`, `itemId: Int!`                    | [Todo](#todo)                                     |
| Mutation | `updateChecklistItemText` |  ✅  | `todoId: Int!`, `itemId: Int!`, `text: String!`   | [Todo](#todo)                                     |
| Mutation | `uncheckAllItems`         |  ✅  | `id: Int!`                                        | [Todo](#todo)                                     |
| Mutation | `updateTodoBackground`    |  ✅  | `id: Int!`, `backgroundImage: String!`            | [Todo](#todo)                                     |

Two things exist on one transport only: `PUT /api/todos/unarchiveAll` and
`DELETE /api/todos/deleteAll` have no GraphQL equivalent, and `updateTodoBackground` — a background
on **one** todo — has no REST equivalent (`PUT /api/background` sets them all).

Input shapes: `CreateTodoInput { title!, content, items: [{ text! }] }`,
`UpdateTodoInput { title, content, items: [{ id!, text!, isCompleted! }] }`,
`UpdateProfileInput { username, email, profileImage, firstName, secondName, description }`,
`UpdateAccountInput { currentPassword!, email, password }`.

##### TYPES

##### User_Notes

[(return to table)](#rest-api-1)

| Field        | Type    |
| ------------ | ------- |
| id           | Int     |
| username     | String  |
| email        | String? |
| firstName    | String? |
| profileImage | String? |
| description  | String  |
| secondName   | String? |
| lastLogin    | String  |
| creationDate | String  |
| modifiedDate | String  |

##### Todo

[(return to table)](#rest-api-1)

| Field           | Type                               |
| --------------- | ---------------------------------- |
| id              | Int                                |
| title           | String                             |
| content         | String?                            |
| items           | [CheckListItem](#checklistitem)[]? |
| status          | [NoteStatus](#notestatus)          |
| backgroundImage | String?                            |
| userId          | Int                                |
| createdAt       | String                             |
| updatedAt       | String                             |

Note the field names: todos use `createdAt` / `updatedAt`, while the social domain uses
`creationDate` / `modifiedDate`.

##### CheckListItem

[(return to table)](#rest-api-1)

| Field       | Type    |
| ----------- | ------- |
| id          | Int     |
| text        | String  |
| isCompleted | Boolean |

`id` is scoped to its todo and starts at 1 — it is not a global row id.

##### NoteStatus

[(return to table)](#rest-api-1)

| Value    |
| -------- |
| NOTES    |
| ARCHIVED |
| TRASH    |

A `CHECK` constraint in the database, so nothing else can ever be stored.
